// screens/SettingsScreen.js
import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import styles from '../src/styles/SettingsScreenStyles';

function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Configurações</Text>

      <TouchableOpacity style={styles.menuButton}>
        <Text style={styles.menuText}>Perfil</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuButton}>
        <Text style={styles.menuText}>Notificações</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuButton}>
        <Text style={styles.menuText}>Privacidade</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuButton}>
        <Text style={styles.menuText}>Ajuda</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuButton}>
        <Text style={styles.menuText}>Sair</Text>
      </TouchableOpacity>
    </View>
  );
}

export default SettingsScreen;