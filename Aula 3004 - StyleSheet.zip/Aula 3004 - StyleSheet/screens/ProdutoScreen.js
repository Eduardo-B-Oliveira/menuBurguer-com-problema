import React from 'react';
import { View, Text, ScrollView, Image } from 'react-native';
import styles from '../src/styles/ProdutoScreenStyles';

const produtos = [
  {
    id: 1,
    nome: 'Pato Branco',
    preco: 100.00,
    quantidade: 3,
    imagem: 'https://blog.polipet.com.br/wp-content/uploads/2024/01/pato.jpeg',
  },
  {
    id: 2,
    nome: 'Pato Preto',
    preco: 100.0,
    quantidade: 3,
    imagem: 'https://www.passaro.org/wp-content/uploads/2023/01/pato-negro.jpg',
  },
  {
    id: 3,
    nome: 'Pato Amarelo',
    preco: 230.0,
    quantidade: 12,
    imagem: 'https://rlv.zcache.com.br/poster_passaro_pato_pato_amarelo_natureza_fofo_bebe-r70dcccd2383044dfa87659897a58d557_w10_8byvr_644.webp',
  },
  {
    id: 4,
    nome: 'Pato Assado',
    preco: 55.0,
    quantidade: 20,
    imagem: 'https://swiftbr.vteximg.com.br/arquivos/pato-assado.jpg',
  },
];

function ProdutoScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tabela de Produtos</Text>
      
      <View style={styles.tableHeader}>
        <Text style={[styles.cell, styles.headerCell, { flex: 2 }]}>Produto</Text>
        <Text style={[styles.cell, styles.headerCell]}>Preço</Text>
        <Text style={[styles.cell, styles.headerCell]}>Quantidade</Text>
      </View>

      <ScrollView>
        {produtos.map((produto) => (
          <View key={produto.id} style={styles.tableRow}>
            <View style={[styles.cell, { flex: 2, flexDirection: 'row', alignItems: 'center' }]}>
              <Image
                source={{ uri: produto.imagem }}
                style={styles.productImage}
                resizeMode="contain"
              />
              <Text style={{ marginLeft: 10 }}>{produto.nome}</Text>
            </View>

            <Text style={styles.cell}>R$ {produto.preco.toFixed(2)}</Text>
            <Text style={styles.cell}>{produto.quantidade}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

export default ProdutoScreen;