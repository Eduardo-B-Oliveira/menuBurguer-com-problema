// screens/HomeScreen.js
import React from 'react';
import { View, Text } from 'react-native';
import styles from '../src/styles/AboutScreenStyles';

function AboutScreen() {
  return (
    <View style={styles.container}>
      <Text>Nós vendemos patos!!!</Text>
      <img src="./imagens/gato.jpg"/>
    </View>
  );
}

export default AboutScreen;