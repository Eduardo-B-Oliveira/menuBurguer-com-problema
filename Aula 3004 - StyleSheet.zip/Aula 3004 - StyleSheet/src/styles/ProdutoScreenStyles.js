import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#99e6f7', // Fundo levemente cinza para contraste
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  tableHeader: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderColor: '#3d9db3',
    marginBottom: 12,
    backgroundColor: '#64d4ed',
    borderRadius: 12,
  },
  tableRow: {
    flexDirection: 'row',
    backgroundColor: '#64d4ed',
    paddingHorizontal: 16,
    paddingVertical: 18,
    marginBottom: 12,
    borderRadius: 16,
    // Sombra leve para iOS
    shadowColor: '#3d9db3',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    // Sombra para Android
    elevation: 3,
    alignItems: 'center',
  },
  cell: {
    flex: 1,
    fontSize: 18,
    color: '#444',
  },
  headerCell: {
    fontWeight: 'bold',
    fontSize: 20,
    color: '#222',
  },
  productImage: {
    width: 200,
    height: 200,
    borderRadius: 12,
    backgroundColor: '#ddd',
  },
});