import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: 60,
      paddingHorizontal: 20,
      backgroundColor: '#1a58c1',
      alignItems: 'center',
      justifyContent: 'center'
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
      textAlign: 'center',
      color: 'white',
    },
    menuButton: {
      width: 300,
      padding: 15,
      borderRadius: 10,
      marginBottom: 15,
      alignItems: 'center',
      elevation: 3,
      backgroundColor: '#8da4e8',
      color: 'white',
    },
    menuText: {
      fontSize: 18,
      color: 'white',
    },
  });

  export default styles;