import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#f0f0f0',
      paddingTop: 40, // Espaço para o status bar
      paddingHorizontal: 20,
      backgroundColor: '#992938',
    },
    header: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
      backgroundColor: '#841f25',
      color: 'white',
    },
    newsItem: {
      backgroundColor: 'white',
      padding: 15,
      marginBottom: 10,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: '#ddd',
      backgroundColor: '#dd9ca3',
    },
    title: {
      fontSize: 18,
      fontWeight: 'bold',
      marginBottom: 5,
    },
    description: {
      fontSize: 16,
      color: '#555',
    },
  });

export default styles;